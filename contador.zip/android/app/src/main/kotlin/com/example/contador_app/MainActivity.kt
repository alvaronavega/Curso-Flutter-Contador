package com.example.contador_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
